import pandas as pd
import numpy as np
from datetime import datetime
import uuid
import streamlit as st
import json
import os

class DataManager:
    def __init__(self):
        # Columns for our dataframes
        self.product_columns = [
            'id', 'name', 'category', 'price', 'stock', 
            'min_stock_level', 'cost_price', 'discount_percent', 
            'discount_end_date', 'created_at', 'barcode'
        ]
        self.sales_columns = [
            'id', 'product_id', 'quantity', 'sale_code', 
            'sale_date', 'original_price', 'discount_applied',
            'cost_price', 'profit', 'total_amount', 'customer_name',
            'status', 'refund_date', 'exchange_for_product_id'
        ]
        
        # Try to load from session state first (for browser local storage)
        if 'products_data' in st.session_state and 'sales_data' in st.session_state:
            try:
                self.products_df = pd.DataFrame(st.session_state.products_data)
                self.sales_df = pd.DataFrame(st.session_state.sales_data)
                return
            except Exception as e:
                st.warning(f"Could not load data from session: {str(e)}")
        
        # Try to load from regular files
        try:
            self.products_df = pd.read_csv('products.csv')
            self.sales_df = pd.read_csv('sales.csv')
        except FileNotFoundError:
            self.products_df = pd.DataFrame(columns=self.product_columns)
            self.sales_df = pd.DataFrame(columns=self.sales_columns)
            self.save_data()

    def save_data(self):
        try:
            # Save to files
            self.products_df.to_csv('products.csv', index=False)
            self.sales_df.to_csv('sales.csv', index=False)
            
            # Save to session state for browser local storage
            st.session_state.products_data = self.products_df.to_dict('records')
            st.session_state.sales_data = self.sales_df.to_dict('records')
            
            # Create a JSON backup for easier mobile export
            combined_data = {
                'products': self.products_df.to_dict('records'),
                'sales': self.sales_df.to_dict('records'),
                'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            with open('data_backup.json', 'w') as f:
                json.dump(combined_data, f)
                
        except Exception as e:
            st.error(f"Error saving data: {str(e)}")
            
    def export_data(self):
        """Generate data for export to mobile devices"""
        # Convert DataFrame to dict with date objects properly converted to strings
        products_dict = []
        for _, row in self.products_df.iterrows():
            product = {}
            for col, val in row.items():
                # Convert date objects to strings to avoid JSON serialization issues
                if isinstance(val, (datetime, pd.Timestamp)):
                    product[col] = val.strftime('%Y-%m-%d %H:%M:%S')
                else:
                    product[col] = val
            products_dict.append(product)
            
        sales_dict = []
        for _, row in self.sales_df.iterrows():
            sale = {}
            for col, val in row.items():
                # Convert date objects to strings
                if isinstance(val, (datetime, pd.Timestamp)):
                    sale[col] = val.strftime('%Y-%m-%d %H:%M:%S')
                else:
                    sale[col] = val
            sales_dict.append(sale)
        
        combined_data = {
            'products': products_dict,
            'sales': sales_dict,
            'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'app_version': '1.0.0',
            'mobile_compatible': True
        }
        return json.dumps(combined_data)
    
    def import_data(self, json_data):
        """Import data from JSON string"""
        try:
            data_dict = json.loads(json_data)
            self.products_df = pd.DataFrame(data_dict['products'])
            self.sales_df = pd.DataFrame(data_dict['sales'])
            self.save_data()
            return True
        except Exception as e:
            st.error(f"Error importing data: {str(e)}")
            return False

    def add_product(self, name, category, price, cost_price, stock, min_stock_level=5, 
                   discount_percent=0, discount_end_date=None, barcode=None):
        try:
            # Generate barcode if not provided
            if not barcode:
                barcode = f"PRD{str(uuid.uuid4())[:8].upper()}"
                
            new_product = {
                'id': str(uuid.uuid4()),
                'name': name,
                'category': category,
                'price': price,
                'cost_price': cost_price,
                'stock': stock,
                'min_stock_level': min_stock_level,
                'discount_percent': discount_percent,
                'discount_end_date': discount_end_date,
                'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'barcode': barcode
            }
            self.products_df = pd.concat([self.products_df, pd.DataFrame([new_product])], ignore_index=True)
            self.save_data()
            return new_product['id']
        except Exception as e:
            st.error(f"Error adding product: {str(e)}")
            return None

    def update_product(self, product_id, name, category, price, cost_price, stock, 
                      min_stock_level, discount_percent=None, discount_end_date=None):
        try:
            idx = self.products_df['id'] == product_id
            if idx.any():
                update_data = {
                    'name': name,
                    'category': category,
                    'price': price,
                    'cost_price': cost_price,
                    'stock': stock,
                    'min_stock_level': min_stock_level
                }
                if discount_percent is not None:
                    update_data['discount_percent'] = discount_percent
                if discount_end_date is not None:
                    update_data['discount_end_date'] = discount_end_date

                for key, value in update_data.items():
                    self.products_df.loc[idx, key] = value

                self.save_data()
                return True
            return False
        except Exception as e:
            st.error(f"Error updating product: {str(e)}")
            return False

    def delete_product(self, product_id):
        try:
            self.products_df = self.products_df[self.products_df['id'] != product_id]
            self.save_data()
            return True
        except Exception as e:
            st.error(f"Error deleting product: {str(e)}")
            return False

    def record_sale(self, product_id, quantity, customer_name=""):
        try:
            product = self.products_df[self.products_df['id'] == product_id].iloc[0]
            if product['stock'] >= quantity:
                original_price = product['price']
                cost_price = product['cost_price']
                discount_amount = 0

                # Check if discount is applicable
                if product['discount_percent'] > 0:
                    if pd.isna(product['discount_end_date']) or \
                       pd.to_datetime(product['discount_end_date']) > datetime.now():
                        discount_amount = (original_price * product['discount_percent']) / 100

                final_price = original_price - discount_amount
                total_amount = quantity * final_price
                total_cost = quantity * cost_price
                profit = total_amount - total_cost

                sale_code = f"SALE-{str(uuid.uuid4())[:8].upper()}"
                new_sale = {
                    'id': str(uuid.uuid4()),
                    'product_id': product_id,
                    'quantity': quantity,
                    'sale_code': sale_code,
                    'sale_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'original_price': original_price,
                    'discount_applied': discount_amount,
                    'cost_price': cost_price,
                    'profit': profit,
                    'total_amount': total_amount,
                    'customer_name': customer_name,
                    'status': 'completed',
                    'refund_date': None,
                    'exchange_for_product_id': None
                }
                self.sales_df = pd.concat([self.sales_df, pd.DataFrame([new_sale])], ignore_index=True)

                # Update stock
                idx = self.products_df['id'] == product_id
                self.products_df.loc[idx, 'stock'] -= quantity
                self.save_data()
                return sale_code
            return None
        except Exception as e:
            st.error(f"Error recording sale: {str(e)}")
            return None

    def get_analytics_data(self):
        try:
            # Sales trends
            sales_per_day = self.sales_df.copy()
            sales_per_day['sale_date'] = pd.to_datetime(sales_per_day['sale_date']).dt.date
            daily_sales = sales_per_day.groupby('sale_date').agg({
                'quantity': 'sum',
                'total_amount': 'sum',
                'discount_applied': 'sum',
                'profit': 'sum'
            }).reset_index()

            # Product performance
            product_performance = pd.merge(
                self.sales_df, 
                self.products_df[['id', 'name', 'category']], 
                left_on='product_id', 
                right_on='id'
            )
            product_stats = product_performance.groupby(['name', 'category']).agg({
                'quantity': 'sum',
                'total_amount': 'sum',
                'discount_applied': 'sum',
                'profit': 'sum'
            }).reset_index()

            # Category performance
            category_stats = product_performance.groupby('category').agg({
                'quantity': 'sum',
                'total_amount': 'sum',
                'discount_applied': 'sum',
                'profit': 'sum'
            }).reset_index()

            # Active discounts
            active_discounts = self.products_df[
                (self.products_df['discount_percent'] > 0) & 
                (pd.isna(self.products_df['discount_end_date']) | 
                (pd.to_datetime(self.products_df['discount_end_date']) > datetime.now()))
            ].copy()

            # Stock alerts
            low_stock = self.products_df[
                self.products_df['stock'] <= self.products_df['min_stock_level']
            ].copy()

            # Recent sales
            recent_sales = pd.merge(
                self.sales_df.tail(10), 
                self.products_df[['id', 'name']], 
                left_on='product_id', 
                right_on='id'
            )

            return {
                'daily_sales': daily_sales,
                'product_stats': product_stats,
                'category_stats': category_stats,
                'active_discounts': active_discounts,
                'low_stock': low_stock,
                'recent_sales': recent_sales,
                'total_products': len(self.products_df),
                'total_sales': self.sales_df['quantity'].sum(),
                'total_revenue': self.sales_df['total_amount'].sum(),
                'total_profit': self.sales_df['profit'].sum(),
                'total_savings': self.sales_df['discount_applied'].sum() * self.sales_df['quantity'].sum(),
                'out_of_stock': len(self.products_df[self.products_df['stock'] == 0])
            }
        except Exception as e:
            st.error(f"Error getting analytics data: {str(e)}")
            return {}

    def find_product_by_barcode(self, barcode):
        """Search for a product by barcode"""
        try:
            matches = self.products_df[self.products_df['barcode'] == barcode]
            if not matches.empty:
                return matches.iloc[0]
            return None
        except Exception as e:
            st.error(f"Error finding product by barcode: {str(e)}")
            return None
    
    def refund_sale(self, sale_id):
        """Process a refund for a sale"""
        try:
            sale_idx = self.sales_df['id'] == sale_id
            if not sale_idx.any():
                return False
                
            # Get sale details
            sale = self.sales_df[sale_idx].iloc[0]
            
            # Check if already refunded or exchanged
            if sale['status'] != 'completed':
                return False
                
            # Update sale status
            self.sales_df.loc[sale_idx, 'status'] = 'refunded'
            self.sales_df.loc[sale_idx, 'refund_date'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            # Return items to inventory
            product_idx = self.products_df['id'] == sale['product_id']
            if product_idx.any():
                current_stock = self.products_df.loc[product_idx, 'stock'].iloc[0]
                self.products_df.loc[product_idx, 'stock'] = current_stock + sale['quantity']
            
            self.save_data()
            return True
        except Exception as e:
            st.error(f"Error processing refund: {str(e)}")
            return False
    
    def exchange_product(self, sale_id, new_product_id, quantity=None):
        """Exchange a product for another"""
        try:
            # Verify sale exists
            sale_idx = self.sales_df['id'] == sale_id
            if not sale_idx.any():
                return False
                
            # Get sale and verify status
            sale = self.sales_df[sale_idx].iloc[0]
            if sale['status'] != 'completed':
                return False
                
            # Verify new product exists
            new_product_idx = self.products_df['id'] == new_product_id
            if not new_product_idx.any():
                return False
                
            new_product = self.products_df[new_product_idx].iloc[0]
            exchange_quantity = quantity if quantity else sale['quantity']
            
            # Check if new product has enough stock
            if new_product['stock'] < exchange_quantity:
                return False
                
            # Update original sale
            self.sales_df.loc[sale_idx, 'status'] = 'exchanged'
            self.sales_df.loc[sale_idx, 'exchange_for_product_id'] = new_product_id
            
            # Return original product to inventory
            orig_product_idx = self.products_df['id'] == sale['product_id']
            if orig_product_idx.any():
                current_stock = self.products_df.loc[orig_product_idx, 'stock'].iloc[0]
                self.products_df.loc[orig_product_idx, 'stock'] = current_stock + sale['quantity']
            
            # Reduce new product stock
            self.products_df.loc[new_product_idx, 'stock'] -= exchange_quantity
            
            # Create a new sale record for the exchanged item
            self.record_sale(
                product_id=new_product_id,
                quantity=exchange_quantity,
                customer_name=sale['customer_name']
            )
            
            self.save_data()
            return True
        except Exception as e:
            st.error(f"Error processing exchange: {str(e)}")
            return False
            
    def cancel_sale(self, sale_id):
        """Cancel a recent sale"""
        try:
            sale_idx = self.sales_df['id'] == sale_id
            if not sale_idx.any():
                return False
                
            # Get sale details
            sale = self.sales_df[sale_idx].iloc[0]
            
            # Check if already refunded or exchanged
            if sale['status'] != 'completed':
                return False
                
            # Calculate time since sale (only allow cancellation within 24 hours)
            sale_time = pd.to_datetime(sale['sale_date'])
            time_diff = datetime.now() - sale_time
            if time_diff.total_seconds() > 86400:  # 24 hours in seconds
                return False
                
            # Update sale status
            self.sales_df.loc[sale_idx, 'status'] = 'cancelled'
            
            # Return items to inventory
            product_idx = self.products_df['id'] == sale['product_id']
            if product_idx.any():
                current_stock = self.products_df.loc[product_idx, 'stock'].iloc[0]
                self.products_df.loc[product_idx, 'stock'] = current_stock + sale['quantity']
            
            self.save_data()
            return True
        except Exception as e:
            st.error(f"Error cancelling sale: {str(e)}")
            return False
