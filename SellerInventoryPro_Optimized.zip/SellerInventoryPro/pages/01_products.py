
import streamlit as st
import pandas as pd
from datetime import datetime, timedelta

st.title("Product Management")

# Add mobile-friendly CSS
st.markdown("""
<style>
    /* Mobile responsive adjustments */
    @media (max-width: 768px) {
        .block-container {
            padding-top: 1rem;
            padding-bottom: 1rem;
        }
        h1 {
            font-size: 1.8rem !important;
        }
        .stForm > div:first-child {
            padding: 1rem 0.5rem !important;
        }
        /* Make buttons full width on mobile */
        .stButton button {
            width: 100%;
        }
        /* Stack form controls in mobile */
        @media (max-width: 640px) {
            div[data-testid="column"] {
                width: 100% !important;
                flex: 1 1 100% !important;
                margin-bottom: 0.5rem;
            }
        }
    }
</style>
""", unsafe_allow_html=True)

# Add New Product Form
with st.expander("➕ Add New Product"):
    with st.form("add_product_form"):
        name = st.text_input("Product Name")
        barcode = st.text_input("Barcode (Optional, will be generated if empty)")
        category = st.selectbox(
            "Category",
            options=["Electronics", "Clothing", "Books", "Home & Garden", "Other"],
            index=0
        )
        
        col1, col2 = st.columns(2)
        with col1:
            price = st.number_input("Price ($)", min_value=0.01, format="%.2f")
        with col2:
            cost_price = st.number_input("Cost Price ($)", min_value=0.01, format="%.2f")
        
        col1, col2 = st.columns(2)
        with col1:
            stock = st.number_input("Initial Stock", min_value=1, step=1)
        with col2:
            min_stock = st.number_input("Low Stock Alert", min_value=1, value=5, step=1)
            
        # Optional discount
        has_discount = st.checkbox("Add Discount")
        if has_discount:
            col1, col2 = st.columns(2)
            with col1:
                discount = st.number_input("Discount %", min_value=0, max_value=100, step=1)
            with col2:
                end_date = st.date_input(
                    "Discount End Date",
                    value=datetime.now() + timedelta(days=7)
                )
        else:
            discount = 0
            end_date = None
            
        submit = st.form_submit_button("Add Product", use_container_width=True)
        
        if submit:
            if name and price > 0 and stock >= 0:
                product_id = st.session_state.data_manager.add_product(
                    name=name,
                    category=category,
                    price=price,
                    cost_price=cost_price,
                    stock=stock,
                    min_stock_level=min_stock,
                    discount_percent=discount,
                    discount_end_date=end_date,
                    barcode=barcode if barcode else None
                )
                if product_id:
                    st.success(f"Product '{name}' added successfully!")
                    st.balloons()
            else:
                st.error("Please fill in all required fields.")

# Search and filter options
st.subheader("Product Inventory")

# Search by barcode
barcode_search = st.text_input("🔍 Scan Barcode", placeholder="Scan barcode...")
if barcode_search:
    product = st.session_state.data_manager.find_product_by_barcode(barcode_search)
    if product is not None:
        st.success(f"Found product: {product['name']}")
        # Display product details
        with st.container():
            st.markdown(f"""
            <div style="padding: 10px; border-radius: 5px; background-color: #f0f2f6; margin-bottom: 10px;">
                <h3 style="margin: 0; font-size: 16px;">{product['name']}</h3>
                <p style="margin: 0; color: #555; font-size: 14px;">{product['category']}</p>
                <p style="margin: 0; color: #555; font-size: 14px;">Barcode: {product['barcode']}</p>
            </div>
            """, unsafe_allow_html=True)
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.caption("Price")
                st.write(f"${product['price']:.2f}")
            with col2:
                st.caption("Stock")
                st.write(f"{product['stock']} units")
            with col3:
                st.caption("Status")
                if product['stock'] == 0:
                    st.markdown("🔴 Out")
                elif product['stock'] <= product['min_stock_level']:
                    st.markdown("🟠 Low")
                else:
                    st.markdown("🟢 Good")
    else:
        st.warning("No product found with that barcode.")

# Mobile friendly search and filter controls
col1, col2 = st.columns(2)
with col1:
    search_term = st.text_input("Search Products", placeholder="Product name...")
with col2:
    category_filter = st.selectbox(
        "Filter by Category",
        options=["All Categories", "Electronics", "Clothing", "Books", "Home & Garden", "Other"]
    )

# Get product data
df = st.session_state.data_manager.products_df

# Apply search and filters
if search_term:
    df = df[df['name'].str.contains(search_term, case=False)]
if category_filter != "All Categories":
    df = df[df['category'] == category_filter]

# Display products
if not df.empty:
    # Mobile-optimized display
    for i, product in df.reset_index(drop=True).iterrows():
        with st.container():
            # Create card-like display
            st.markdown(f"""
            <div style="padding: 10px; border-radius: 5px; background-color: #f0f2f6; margin-bottom: 10px;">
                <h3 style="margin: 0; font-size: 16px;">{product['name']}</h3>
                <p style="margin: 0; color: #555; font-size: 14px;">{product['category']}</p>
            </div>
            """, unsafe_allow_html=True)
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.caption("Price")
                st.write(f"${product['price']:.2f}")
            with col2:
                st.caption("Stock")
                st.write(f"{product['stock']} units")
            with col3:
                st.caption("Status")
                if product['stock'] == 0:
                    st.markdown("🔴 Out")
                elif product['stock'] <= product['min_stock_level']:
                    st.markdown("🟠 Low")
                else:
                    st.markdown("🟢 Good")
            
            # Actions
            col1, col2 = st.columns(2)
            with col1:
                if st.button("📝 Edit", key=f"edit_{i}", use_container_width=True):
                    st.session_state.edit_product_id = product['id']
            with col2:
                if st.button("❌ Delete", key=f"delete_{i}", use_container_width=True):
                    st.session_state.delete_product_id = product['id']
                    st.session_state.delete_product_name = product['name']
            
            st.markdown("---")
    
    # Product Edit Form (shown when edit button is clicked)
    if 'edit_product_id' in st.session_state and st.session_state.edit_product_id:
        product_to_edit = df[df['id'] == st.session_state.edit_product_id].iloc[0]
        
        st.subheader(f"Edit Product: {product_to_edit['name']}")
        with st.form("edit_product_form"):
            name = st.text_input("Product Name", value=product_to_edit['name'])
            category = st.selectbox(
                "Category",
                options=["Electronics", "Clothing", "Books", "Home & Garden", "Other"],
                index=["Electronics", "Clothing", "Books", "Home & Garden", "Other"].index(product_to_edit['category'])
            )
            
            col1, col2 = st.columns(2)
            with col1:
                price = st.number_input("Price ($)", 
                                       min_value=0.01, 
                                       value=float(product_to_edit['price']), 
                                       format="%.2f")
            with col2:
                cost_price = st.number_input("Cost Price ($)", 
                                            min_value=0.01, 
                                            value=float(product_to_edit['cost_price']), 
                                            format="%.2f")
            
            col1, col2 = st.columns(2)
            with col1:
                stock = st.number_input("Stock", 
                                       min_value=0, 
                                       value=int(product_to_edit['stock']))
            with col2:
                min_stock = st.number_input("Low Stock Alert", 
                                           min_value=1, 
                                           value=int(product_to_edit['min_stock_level']))
                
            # Optional discount
            has_discount = st.checkbox("Add Discount", 
                                      value=True if product_to_edit['discount_percent'] > 0 else False)
            if has_discount:
                col1, col2 = st.columns(2)
                with col1:
                    discount = st.number_input("Discount %", 
                                              min_value=0, 
                                              max_value=100, 
                                              value=int(product_to_edit['discount_percent']))
                with col2:
                    end_date = st.date_input(
                        "Discount End Date",
                        value=pd.to_datetime(product_to_edit['discount_end_date']) 
                              if pd.notna(product_to_edit['discount_end_date']) 
                              else (datetime.now() + timedelta(days=7))
                    )
            else:
                discount = 0
                end_date = None
                
            col1, col2 = st.columns(2)
            with col1:
                submit = st.form_submit_button("Update Product", use_container_width=True)
            with col2:
                cancel = st.form_submit_button("Cancel", use_container_width=True)
            
            if submit:
                if name and price > 0:
                    success = st.session_state.data_manager.update_product(
                        product_id=st.session_state.edit_product_id,
                        name=name,
                        category=category,
                        price=price,
                        cost_price=cost_price,
                        stock=stock,
                        min_stock_level=min_stock,
                        discount_percent=discount,
                        discount_end_date=end_date
                    )
                    if success:
                        st.success(f"Product '{name}' updated successfully!")
                        st.session_state.edit_product_id = None
                        st.rerun()
                else:
                    st.error("Please fill in all required fields.")
            
            if cancel:
                st.session_state.edit_product_id = None
                st.rerun()
    
    # Delete confirmation
    if 'delete_product_id' in st.session_state and st.session_state.delete_product_id:
        st.warning(f"Are you sure you want to delete '{st.session_state.delete_product_name}'?")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Confirm Delete", use_container_width=True, key="confirm_delete"):
                success = st.session_state.data_manager.delete_product(st.session_state.delete_product_id)
                if success:
                    st.success(f"Product '{st.session_state.delete_product_name}' deleted!")
                    st.session_state.delete_product_id = None
                    st.session_state.delete_product_name = None
                    st.rerun()
        with col2:
            if st.button("Cancel", use_container_width=True, key="cancel_delete"):
                st.session_state.delete_product_id = None
                st.session_state.delete_product_name = None
                st.rerun()
else:
    st.info("No products found matching your search criteria.")

# Display stock alerts
low_stock = df[df['stock'] <= df['min_stock_level']]
if not low_stock.empty:
    st.markdown("---")
    st.subheader("⚠️ Stock Alerts")
    for _, product in low_stock.iterrows():
        remaining_percent = (product['stock'] / product['min_stock_level']) * 100
        status = "Critical" if product['stock'] == 0 else "Low" if remaining_percent < 50 else "Warning"
        st.warning(
            f"⚠️ {product['name']} ({product['category']})\n"
            f"Current Stock: {product['stock']} units ({status})"
        )
