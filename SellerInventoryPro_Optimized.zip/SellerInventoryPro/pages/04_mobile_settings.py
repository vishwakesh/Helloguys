import streamlit as st
import pandas as pd
import json
import base64
from datetime import datetime

st.title("📱 Mobile Settings")

st.markdown("""
<style>
    /* Mobile friendly adjustments */
    @media (max-width: 768px) {
        .block-container {
            padding-top: 1rem;
            padding-bottom: 1rem;
        }
        h1 {
            font-size: 1.8rem !important;
        }
        .stButton button {
            width: 100%;
            margin-bottom: 10px;
        }
    }
</style>
""", unsafe_allow_html=True)

# Local Storage Information
st.subheader("📊 Data Storage Status")

# Get information about current data
products_size = len(st.session_state.data_manager.products_df)
sales_size = len(st.session_state.data_manager.sales_df)

# Calculate transaction statistics
sales_df = st.session_state.data_manager.sales_df
completed_sales = len(sales_df[sales_df['status'] == 'completed'])
refunded_sales = len(sales_df[sales_df['status'] == 'refunded'])
exchanged_sales = len(sales_df[sales_df['status'] == 'exchanged'])
cancelled_sales = len(sales_df[sales_df['status'] == 'cancelled'])

# Calculate total data size
total_data_kb = (
    st.session_state.data_manager.products_df.memory_usage(deep=True).sum() / 1024 +
    st.session_state.data_manager.sales_df.memory_usage(deep=True).sum() / 1024
)

st.info(f"""
**Current Data Stats:**
- {products_size} products stored
- {sales_size} total transaction records
  - {completed_sales} completed sales
  - {refunded_sales} refunds
  - {exchanged_sales} exchanges
  - {cancelled_sales} cancellations
- Approx. {total_data_kb:.2f} KB of data
""")

# Data Backup & Restore
st.subheader("💾 Backup & Restore")

tab1, tab2 = st.tabs(["Export", "Import"])

with tab1:
    st.write("Export your data to use on other devices or for backup:")

    # Create a download link
    if st.button("📤 Export Data", type="primary", use_container_width=True):
        export_data = st.session_state.data_manager.export_data()
        b64 = base64.b64encode(export_data.encode()).decode()
        current_date = datetime.now().strftime("%Y%m%d")
        filename = f"inventory_data_{current_date}.json"
        href = f'<a href="data:file/json;base64,{b64}" download="{filename}">Download data file</a>'
        st.markdown(href, unsafe_allow_html=True)
        st.success("Data prepared for download! Click the link above.")

with tab2:
    st.write("Import data from another device or restore from backup:")
    uploaded_file = st.file_uploader("Upload backup file (.json)", type=["json"])

    if uploaded_file is not None:
        try:
            json_data = uploaded_file.read().decode("utf-8")
            if st.button("📥 Import Data", type="primary", use_container_width=True):
                success = st.session_state.data_manager.import_data(json_data)
                if success:
                    st.success("Data imported successfully!")
                    st.balloons()
                else:
                    st.error("Failed to import data. Check file format.")
        except Exception as e:
            st.error(f"Error reading file: {str(e)}")

# Offline Mode Settings
st.subheader("🔌 Offline Mode")

offline_mode = st.checkbox("Work Offline", value=False, 
                          help="Enable to work without internet connection")

if offline_mode:
    st.success("Offline mode enabled. All changes will be stored locally.")
else:
    st.info("Changes will be synchronized when online.")

# Storage Management
st.subheader("🧹 Storage Management")

st.warning("These actions cannot be undone!")

col1, col2 = st.columns(2)
with col1:
    if st.button("Clear All Data", use_container_width=True):
        st.session_state.show_confirm = True

with col2:
    if st.button("Reset App", use_container_width=True):
        st.session_state.show_reset = True

# Confirmation dialogs
if st.session_state.get("show_confirm", False):
    st.warning("⚠️ This will delete ALL your inventory and sales data. Are you sure?")
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Yes, Clear Data", key="confirm_clear"):
            # Initialize empty dataframes
            st.session_state.data_manager.products_df = pd.DataFrame(
                columns=st.session_state.data_manager.product_columns)
            st.session_state.data_manager.sales_df = pd.DataFrame(
                columns=st.session_state.data_manager.sales_columns)
            st.session_state.data_manager.save_data()
            st.success("All data cleared successfully!")
            st.session_state.show_confirm = False
            st.rerun()
    with col2:
        if st.button("Cancel", key="cancel_clear"):
            st.session_state.show_confirm = False
            st.rerun()

if st.session_state.get("show_reset", False):
    st.warning("⚠️ This will reset the entire app to default settings. Are you sure?")
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Yes, Reset App", key="confirm_reset"):
            # Clear session state
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            st.success("App reset successfully! Reloading...")
            st.rerun()
    with col2:
        if st.button("Cancel", key="cancel_reset"):
            st.session_state.show_reset = False
            st.rerun()

# Mobile usage tips
with st.expander("📱 Mobile Usage Tips"):
    st.markdown("""
    ### Tips for Mobile Users

    - **Offline Mode**: Enable offline mode when using with limited internet
    - **Data Backup**: Export your data regularly to prevent loss
    - **Storage Usage**: Clear old data to keep the app running smoothly
    - **Portrait Mode**: The app works best in portrait orientation on mobile
    - **Zoom Issues**: If elements appear cut off, try zooming out slightly
    """)