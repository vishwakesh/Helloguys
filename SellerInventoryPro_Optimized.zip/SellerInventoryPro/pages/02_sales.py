import streamlit as st
import pandas as pd
from datetime import datetime

st.title("💰 Sales Management")

# Add mobile-friendly CSS
st.markdown("""
<style>
    /* Mobile responsive adjustments */
    @media (max-width: 768px) {
        .block-container {
            padding-top: 1rem;
            padding-bottom: 1rem;
        }
        h1 {
            font-size: 1.8rem !important;
        }
        /* Stack columns in mobile */
        @media (max-width: 640px) {
            div[data-testid="column"] {
                width: 100% !important;
                flex: 1 1 100% !important;
                margin-bottom: 0.5rem;
            }
        }
        /* Make expanders more compact */
        .streamlit-expanderHeader {
            font-size: 0.9rem !important;
        }
    }
</style>
""", unsafe_allow_html=True)

# Record New Sale
st.subheader("📝 Record New Sale")

products_df = st.session_state.data_manager.products_df
available_products = products_df[products_df['stock'] > 0]

if not available_products.empty:
    with st.form("record_sale"):
        # Product selection with category grouping
        product_options = available_products.apply(
            lambda x: f"{x['name']} ({x['category']}) - ${x['price']:.2f} - {x['stock']} in stock",
            axis=1
        ).tolist()

        product_index = st.selectbox(
            "Select Product",
            range(len(product_options)),
            format_func=lambda x: product_options[x]
        )

        selected_product = available_products.iloc[product_index]
        max_stock = int(selected_product['stock'])

        col1, col2 = st.columns(2)
        with col1:
            quantity = st.number_input(
                "Quantity",
                min_value=1,
                max_value=max_stock,
                value=1
            )
        with col2:
            total_price = quantity * selected_product['price']
            st.markdown(f"**Total Price**: ${total_price:.2f}")

        submit_sale = st.form_submit_button("💰 Record Sale")

        if submit_sale:
            sale_code = st.session_state.data_manager.record_sale(
                selected_product['id'],
                quantity
            )
            if sale_code:
                st.success(f"✅ Sale recorded successfully!\nSale Code: {sale_code}")
                st.balloons()
                st.rerun()
            else:
                st.error("❌ Error recording sale. Please check stock availability.")
else:
    st.warning("⚠️ No products available for sale.")

# Sales History
st.markdown("---")
st.subheader("📜 Sales History")

# Date filter
col1, col2 = st.columns(2)
with col1:
    start_date = st.date_input(
        "Start Date",
        value=datetime.now().date(),
        max_value=datetime.now().date()
    )
with col2:
    end_date = st.date_input(
        "End Date",
        value=datetime.now().date(),
        max_value=datetime.now().date()
    )

sales_df = st.session_state.data_manager.sales_df
if not sales_df.empty:
    # Convert sale_date to datetime for filtering
    sales_df['sale_date'] = pd.to_datetime(sales_df['sale_date'])

    # Filter by date range
    mask = (
        (sales_df['sale_date'].dt.date >= start_date) &
        (sales_df['sale_date'].dt.date <= end_date)
    )
    filtered_sales = sales_df[mask]

    # Merge with products to get product details
    sales_history = pd.merge(
        filtered_sales,
        products_df[['id', 'name', 'category', 'price']],
        left_on='product_id',
        right_on='id',
        suffixes=('', '_product')
    )

    # Display summary metrics
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric(
            "Total Sales",
            len(filtered_sales),
            help="Number of sales in selected period"
        )
    with col2:
        st.metric(
            "Total Units",
            filtered_sales['quantity'].sum(),
            help="Total units sold in selected period"
        )
    with col3:
        st.metric(
            "Total Revenue",
            f"${filtered_sales['total_amount'].sum():,.2f}",
            help="Total revenue in selected period"
        )

    # Display detailed sales history
    sales_history = sales_history.sort_values('sale_date', ascending=False)

    for _, sale in sales_history.iterrows():
        with st.expander(
            f"🧾 {sale['sale_date'].strftime('%Y-%m-%d %H:%M')} - {sale['name']} - {sale['sale_code']}"
        ):
            col1, col2 = st.columns(2)
            with col1:
                st.write(f"**Product**: {sale['name']}")
                st.write(f"**Category**: {sale['category']}")
                st.write(f"**Quantity**: {sale['quantity']} units")
            with col2:
                st.write(f"**Unit Price**: ${sale['price']:.2f}")
                st.write(f"**Total Amount**: ${sale['total_amount']:.2f}")
                st.write(f"**Sale Code**: {sale['sale_code']}")
else:
    st.info("📝 No sales recorded yet.")
import streamlit as st
import pandas as pd
from datetime import datetime

st.title("Sales Management")

# Add mobile-friendly CSS
st.markdown("""
<style>
    /* Mobile responsive adjustments */
    @media (max-width: 768px) {
        .block-container {
            padding-top: 1rem;
            padding-bottom: 1rem;
        }
        h1 {
            font-size: 1.8rem !important;
        }
        /* Make buttons full width on mobile */
        .stButton button {
            width: 100%;
        }
        /* Stack form controls in mobile */
        @media (max-width: 640px) {
            div[data-testid="column"] {
                width: 100% !important;
                flex: 1 1 100% !important;
                margin-bottom: 0.5rem;
            }
        }
    }
</style>
""", unsafe_allow_html=True)

# Barcode scanning for quick sales
st.subheader("Quick Sale by Barcode")
barcode_input = st.text_input("🔍 Scan Barcode", placeholder="Scan product barcode...")
if barcode_input:
    product = st.session_state.data_manager.find_product_by_barcode(barcode_input)
    if product is not None and product['stock'] > 0:
        st.success(f"Found product: {product['name']} - ${product['price']:.2f}")
        
        with st.form("quick_sale_form"):
            quantity = st.number_input("Quantity", min_value=1, max_value=int(product['stock']), value=1)
            customer_name = st.text_input("Customer Name (Optional)")
            submit = st.form_submit_button("Complete Sale", use_container_width=True)
            
            if submit:
                sale_code = st.session_state.data_manager.record_sale(
                    product_id=product['id'],
                    quantity=quantity,
                    customer_name=customer_name
                )
                if sale_code:
                    st.success(f"Sale recorded successfully! Sale Code: {sale_code}")
                    st.balloons()
                    st.rerun()
                else:
                    st.error("Failed to record sale. Please try again.")
    elif product is not None and product['stock'] <= 0:
        st.warning(f"Product '{product['name']}' is out of stock.")
    else:
        st.warning("No product found with that barcode.")

st.markdown("---")
# Record Sales Form
st.subheader("Record New Sale")

# Get available products
products_df = st.session_state.data_manager.products_df
if not products_df.empty:
    # Filter to only show products with stock
    available_products = products_df[products_df['stock'] > 0].copy()
    
    if not available_products.empty:
        with st.form("record_sale_form"):
            # Product selection
            product_names = available_products['name'].tolist()
            product_name = st.selectbox("Select Product", options=product_names)
            selected_product = available_products[available_products['name'] == product_name].iloc[0]
            
            # Display product info
            col1, col2 = st.columns(2)
            with col1:
                st.caption("Price")
                st.write(f"${selected_product['price']:.2f}")
                
                # Show discount if applicable
                if selected_product['discount_percent'] > 0:
                    discount_price = selected_product['price'] * (1 - selected_product['discount_percent']/100)
                    st.caption("Discounted Price")
                    st.write(f"${discount_price:.2f} ({selected_product['discount_percent']}% off)")
            
            with col2:
                st.caption("Available Stock")
                st.write(f"{selected_product['stock']} units")
            
            # Quantity selector
            quantity = st.number_input(
                "Quantity", 
                min_value=1, 
                max_value=int(selected_product['stock']), 
                value=1,
                step=1
            )
            
            # Customer information
            customer_name = st.text_input("Customer Name (Optional)")
            
            # Calculate total
            product_price = selected_product['price']
            if selected_product['discount_percent'] > 0:
                discount_amount = product_price * (selected_product['discount_percent'] / 100)
                final_price = product_price - discount_amount
            else:
                final_price = product_price
                
            total_amount = quantity * final_price
            
            st.markdown(f"**Total: ${total_amount:.2f}**")
            
            # Submit button
            submit = st.form_submit_button("Record Sale", use_container_width=True)
            
            if submit:
                sale_code = st.session_state.data_manager.record_sale(
                    product_id=selected_product['id'], 
                    quantity=quantity,
                    customer_name=customer_name
                )
                if sale_code:
                    st.success(f"Sale recorded successfully! Sale Code: {sale_code}")
                    st.balloons()
                else:
                    st.error("Failed to record sale. Please try again.")
    else:
        st.warning("No products available for sale. All products are out of stock.")
else:
    st.warning("No products available. Please add products first.")

# Sales History
st.markdown("---")
st.subheader("Recent Sales")

# Filter options
col1, col2 = st.columns(2)
with col1:
    days_filter = st.selectbox(
        "Time Period", 
        options=["Today", "Last 7 Days", "Last 30 Days", "All Time"],
        index=1
    )
with col2:
    sort_order = st.selectbox(
        "Sort By", 
        options=["Most Recent", "Oldest First"],
        index=0
    )

# Get sales data
sales_df = st.session_state.data_manager.sales_df

# Apply filters
if not sales_df.empty:
    sales_df['sale_date'] = pd.to_datetime(sales_df['sale_date'])
    
    if days_filter == "Today":
        sales_df = sales_df[sales_df['sale_date'].dt.date == datetime.now().date()]
    elif days_filter == "Last 7 Days":
        sales_df = sales_df[sales_df['sale_date'] >= (datetime.now() - pd.Timedelta(days=7))]
    elif days_filter == "Last 30 Days":
        sales_df = sales_df[sales_df['sale_date'] >= (datetime.now() - pd.Timedelta(days=30))]
    
    # Sort
    if sort_order == "Most Recent":
        sales_df = sales_df.sort_values('sale_date', ascending=False)
    else:
        sales_df = sales_df.sort_values('sale_date', ascending=True)
    
    # Display sales
    if not sales_df.empty:
        # Get product names
        merged_sales = pd.merge(
            sales_df,
            products_df[['id', 'name', 'category']],
            left_on='product_id',
            right_on='id',
            how='left'
        )
        
        # Display in mobile-friendly cards
        for _, sale in merged_sales.iterrows():
            with st.container():
                # Create card-like display
                st.markdown(f"""
                <div style="padding: 10px; border-radius: 5px; background-color: #f0f2f6; margin-bottom: 10px;">
                    <h3 style="margin: 0; font-size: 16px;">{sale['sale_code']}</h3>
                    <p style="margin: 0; color: #555; font-size: 14px;">{sale['sale_date'].strftime('%Y-%m-%d %H:%M')}</p>
                </div>
                """, unsafe_allow_html=True)
                
                col1, col2 = st.columns(2)
                with col1:
                    st.caption("Product")
                    st.write(f"{sale['name']}")
                    st.caption("Category")
                    st.write(f"{sale['category']}")
                with col2:
                    st.caption("Quantity")
                    st.write(f"{sale['quantity']} units")
                    st.caption("Total")
                    st.write(f"${sale['total_amount']:.2f}")
                
                # Add action buttons for sale management
                col1, col2, col3 = st.columns(3)
                with col1:
                    if st.button("↩️ Refund", key=f"refund_{sale['id']}", use_container_width=True):
                        if sale['status'] == 'completed':
                            if st.session_state.data_manager.refund_sale(sale['id']):
                                st.success("Refund processed successfully!")
                                st.rerun()
                            else:
                                st.error("Failed to process refund")
                        else:
                            st.warning(f"Cannot refund a sale with status: {sale['status']}")
                
                with col2:
                    if st.button("🔄 Exchange", key=f"exchange_{sale['id']}", use_container_width=True):
                        if sale['status'] == 'completed':
                            st.session_state.exchange_sale_id = sale['id']
                            st.session_state.exchange_product_name = sale['name']
                            st.rerun()
                        else:
                            st.warning(f"Cannot exchange a sale with status: {sale['status']}")
                
                with col3:
                    if st.button("❌ Cancel", key=f"cancel_{sale['id']}", use_container_width=True):
                        if sale['status'] == 'completed':
                            if st.session_state.data_manager.cancel_sale(sale['id']):
                                st.success("Sale cancelled successfully!")
                                st.rerun()
                            else:
                                st.error("Failed to cancel sale. Only sales within 24 hours can be cancelled.")
                        else:
                            st.warning(f"Cannot cancel a sale with status: {sale['status']}")
                
                st.markdown("---")
    
    # Exchange product form
    if 'exchange_sale_id' in st.session_state and st.session_state.exchange_sale_id:
        st.subheader(f"Exchange Product: {st.session_state.exchange_product_name}")
        
        # Get available products for exchange
        available_products = products_df[products_df['stock'] > 0].copy()
        
        if not available_products.empty:
            with st.form("exchange_product_form"):
                # Product selection
                product_names = available_products['name'].tolist()
                new_product_name = st.selectbox("Select New Product", options=product_names)
                new_product = available_products[available_products['name'] == new_product_name].iloc[0]
                
                # Display product info
                col1, col2 = st.columns(2)
                with col1:
                    st.caption("Price")
                    st.write(f"${new_product['price']:.2f}")
                
                with col2:
                    st.caption("Available Stock")
                    st.write(f"{new_product['stock']} units")
                
                # Quantity selector
                quantity = st.number_input(
                    "Quantity", 
                    min_value=1, 
                    max_value=int(new_product['stock']), 
                    value=1,
                    step=1
                )
                
                col1, col2 = st.columns(2)
                with col1:
                    submit = st.form_submit_button("Complete Exchange", use_container_width=True)
                with col2:
                    cancel = st.form_submit_button("Cancel Exchange", use_container_width=True)
                
                if submit:
                    success = st.session_state.data_manager.exchange_product(
                        sale_id=st.session_state.exchange_sale_id,
                        new_product_id=new_product['id'],
                        quantity=quantity
                    )
                    if success:
                        st.success("Exchange processed successfully!")
                        del st.session_state.exchange_sale_id
                        del st.session_state.exchange_product_name
                        st.rerun()
                    else:
                        st.error("Failed to process exchange")
                
                if cancel:
                    del st.session_state.exchange_sale_id
                    del st.session_state.exchange_product_name
                    st.rerun()
        else:
            st.warning("No products available for exchange. All products are out of stock.")
            if st.button("Cancel Exchange"):
                del st.session_state.exchange_sale_id
                del st.session_state.exchange_product_name
                st.rerun()
                
    else:
        st.info(f"No sales found for the selected period.")
else:
    st.info("No sales recorded yet.")
