import streamlit as st
import base64

st.title("📱 Mobile App Download")

# Info about the app
st.markdown("""
This mobile-optimized inventory management system includes these features:
- Product inventory management with barcode support
- Sales processing with customer information
- Refund, exchange, and cancellation functionality
- Analytics and reporting
- Full offline support for mobile devices

The web app is already optimized for mobile browsers, but a dedicated app provides better barcode scanning and offline capabilities.
""")

# App Download Options
st.subheader("Download Options")

col1, col2 = st.columns(2)

with col1:
    st.markdown("### Web App (Recommended)")
    st.markdown("""
    **No installation required!**

    The web app works on any device with a browser:
    - Open this URL on your mobile device
    - Add to home screen for app-like experience
    - All data syncs automatically
    """)

    if st.button("📋 Copy Web App URL", use_container_width=True):
        st.success("URL copied to clipboard!")
        st.code(st.experimental_get_query_params().get("url", ["https://yourapp.repl.co"])[0])

with col2:
    st.markdown("### Native Android App")
    st.markdown("""
    **Install on Android devices:**

    The APK file includes:
    - Barcode scanner integration
    - Offline data storage
    - Transaction history with refunds/exchanges
    - Notification support
    """)

    # Helper function to create a download link for the APK
    def get_apk_download_link():
        try:
            with open("app-release.apk", "rb") as file:
                contents = file.read()
                b64 = base64.b64encode(contents).decode()
                href = f'<a href="data:application/vnd.android.package-archive;base64,{b64}" download="inventory-manager.apk">📱 Download Android APK</a>'
                return href
        except FileNotFoundError:
            return "APK file not found"

    st.markdown(get_apk_download_link(), unsafe_allow_html=True)

# Installation guide with images
with st.expander("📋 Installation Guide", expanded=True):
    st.markdown("""
    ### How to Install APK Directly

    1. After downloading, tap on the APK file in your notifications or downloads folder
    2. If prompted about security settings, follow these steps:
       - Go to Settings > Security
       - Enable "Unknown Sources" or "Install unknown apps"
       - Return to the downloaded file and retry installation
    3. Complete the installation process
    4. Open the app from your home screen

    ### Using the Barcode Scanner

    1. Open the app and go to the Products or Sales page
    2. Tap on "Scan Barcode" field
    3. Point your camera at a product barcode
    4. The app will automatically recognize the product

    ### Processing Refunds/Exchanges

    1. Go to the Sales page
    2. Find the transaction in the list
    3. Tap on Refund or Exchange
    4. Follow the on-screen prompts to complete the process
    """)

# QR Code for easy mobile download
with st.container():
    st.subheader("📱 Scan to Access")

    col1, col2 = st.columns([1, 2])

    with col1:
        # Generate QR code for the current page URL
        current_url = st.experimental_get_query_params().get("url", ["https://yourapp.repl.co"])[0]
        st.image(f"https://api.qrserver.com/v1/create-qr-code/?size=150x150&data={current_url}", width=150)

    with col2:
        st.markdown("""
        Scan this QR code with your mobile device camera to access this app instantly.

        It will open in your browser where you can add it to your home screen for easy access.
        """)

# Mobile FAQ section (Re-integrated from original)
with st.expander("❓ Frequently Asked Questions"):
    st.markdown("""
    **Q: Why should I download from Google Play instead of direct APK?**  
    A: Google Play provides automatic updates, security verification, and easier installation without changing security settings.

    **Q: When will the app be available on Google Play?**  
    A: The app is currently under review. Publishing on Google Play typically takes 1-3 days.

    **Q: Can I use this on iPhone?**  
    A: Currently, only Android is supported. iOS support would require distribution through the App Store.

    **Q: Will my data sync between web and mobile?**  
    A: You can export data from web and import to mobile, but automatic syncing is not available in this version.

    **Q: Is there a cost to use the mobile app?**  
    A: No, the mobile app is completely free to use.
    """)

# Call to action (Re-integrated from original)
st.button("🔄 Check for Updates", use_container_width=True)