
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd

st.title("Analytics Dashboard")

# Mobile-friendly layout
st.markdown("""
<style>
    /* Mobile-friendly adjustments */
    @media (max-width: 768px) {
        .stPlotlyChart {
            height: 300px !important;
        }
        h1 {
            font-size: 1.8rem !important;
        }
        h3 {
            font-size: 1.2rem !important;
        }
    }
</style>
""", unsafe_allow_html=True)

analytics_data = st.session_state.data_manager.get_analytics_data()

# Compact date range selector for mobile
st.subheader("Filter Data")
col1, col2 = st.columns(2)
with col1:
    start_date = st.date_input("From", value=pd.to_datetime("today") - pd.Timedelta(days=30))
with col2:
    end_date = st.date_input("To", value=pd.to_datetime("today"))

# Tabs for better mobile organization
tabs = st.tabs(["Sales", "Products", "Stock", "Profitability"])

with tabs[0]:
    st.subheader("Sales Trend")
    daily_sales = analytics_data.get('daily_sales', pd.DataFrame())
    if not daily_sales.empty:
        # Filter by date
        if 'sale_date' in daily_sales.columns:
            daily_sales['sale_date'] = pd.to_datetime(daily_sales['sale_date'])
            filtered_sales = daily_sales[
                (daily_sales['sale_date'].dt.date >= start_date) & 
                (daily_sales['sale_date'].dt.date <= end_date)
            ]
            
            # Compact metrics
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Total Units", filtered_sales['quantity'].sum())
            with col2:
                st.metric("Revenue", f"${filtered_sales['total_amount'].sum():,.2f}")
            
            # Mobile-optimized chart
            fig_sales = px.line(
                filtered_sales,
                x='sale_date',
                y='quantity',
                title='Daily Sales Units'
            )
            fig_sales.update_layout(
                height=300,
                margin=dict(l=10, r=10, t=40, b=10),
                xaxis_title=None,
                title_x=0.5
            )
            st.plotly_chart(fig_sales, use_container_width=True)
        else:
            st.info("No sales trend data available yet.")
    else:
        st.info("No sales data available yet.")

with tabs[1]:
    st.subheader("Product Performance")
    product_stats = analytics_data.get('product_stats', pd.DataFrame())
    if not product_stats.empty:
        # Top products chart
        top_products = product_stats.sort_values('quantity', ascending=False).head(5)
        fig_products = px.bar(
            top_products,
            x='name',
            y='quantity',
            title='Top 5 Products (Units Sold)'
        )
        fig_products.update_layout(
            height=300,
            margin=dict(l=10, r=10, t=40, b=10),
            xaxis_title=None,
            title_x=0.5
        )
        st.plotly_chart(fig_products, use_container_width=True)
        
        # Category breakdown
        fig_category = px.pie(
            product_stats.groupby('category').sum().reset_index(),
            values='quantity',
            names='category',
            title='Sales by Category'
        )
        fig_category.update_layout(
            height=300,
            margin=dict(l=10, r=10, t=40, b=10),
            title_x=0.5,
            legend=dict(orientation="h", yanchor="bottom", y=-0.3, xanchor="center", x=0.5)
        )
        st.plotly_chart(fig_category, use_container_width=True)
    else:
        st.info("No product performance data available yet.")

with tabs[2]:
    st.subheader("Current Stock Levels")
    products_df = st.session_state.data_manager.products_df
    if not products_df.empty:
        # Stock summary metrics
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Total Items", products_df['stock'].sum())
        with col2:
            low_stock_count = len(products_df[products_df['stock'] <= products_df['min_stock_level']])
            st.metric("Low Stock Items", low_stock_count, delta=None, delta_color="inverse")
        
        # Mobile-friendly stock chart
        top_products = products_df.sort_values('stock').head(5)
        fig_stock = px.bar(
            top_products,
            x='name',
            y='stock',
            title='Lowest Stock Items',
            color='stock',
            color_continuous_scale=["red", "orange", "green"],
        )
        fig_stock.update_layout(
            height=300,
            margin=dict(l=10, r=10, t=40, b=10),
            xaxis_title=None,
            title_x=0.5,
            coloraxis_showscale=False
        )
        st.plotly_chart(fig_stock, use_container_width=True)
        
        # Stock Alerts in collapsible section
        low_stock = products_df[products_df['stock'] < products_df['min_stock_level']]
        with st.expander("Stock Alerts", expanded=False):
            if not low_stock.empty:
                for _, product in low_stock.iterrows():
                    st.warning(f"⚠️ {product['name']}: {product['stock']} units remaining")
            else:
                st.success("No stock alerts!")
    else:
        st.info("No products available for stock analysis.")

with tabs[3]:
    st.subheader("Profitability Analysis")
    if 'product_stats' in analytics_data and not analytics_data['product_stats'].empty:
        profit_data = analytics_data['product_stats'].sort_values('profit', ascending=False).head(5)
        
        # Profit metrics
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Total Profit", f"${analytics_data.get('total_profit', 0):,.2f}")
        with col2:
            st.metric("Avg. Margin", f"{(analytics_data.get('total_profit', 0) / analytics_data.get('total_revenue', 1) * 100):.1f}%")
        
        # Profit chart
        fig_profit = px.bar(
            profit_data,
            x='name',
            y='profit',
            title='Most Profitable Products'
        )
        fig_profit.update_layout(
            height=300,
            margin=dict(l=10, r=10, t=40, b=10),
            xaxis_title=None,
            title_x=0.5
        )
        st.plotly_chart(fig_profit, use_container_width=True)
    else:
        st.info("No profitability data available yet.")

# Mobile data management
st.markdown("---")
with st.expander("📱 Mobile Data Options"):
    st.info("Your data is stored locally on your device")
    
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Download Data", key="download_button"):
            st.success("Data downloaded to your device")
    with col2:
        if st.button("Clear Cache", key="clear_cache_button"):
            st.warning("This will delete all local data")
